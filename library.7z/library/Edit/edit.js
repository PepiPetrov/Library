async function add() {
    const old = document.getElementById('old').value
    const title = document.getElementById('newTitle').value
    const author = document.getElementById('newAuthor').value
    const description = document.getElementById('newDescripion').value
    const publisher = document.getElementById('newPublisher').value
    const yearOfPublishing = document.getElementById('newYear').value
    const img = document.getElementById('newImg').value
    const genre=document.getElementById('newGenre').value
    const book = { name: title, author, description, publisher, year: yearOfPublishing, img ,genre}
    const value = await getData()
    const key = findBook(old, value)
    fetch('https://books-76270-default-rtdb.firebaseio.com/books/' + key+'.json', {
        method: "put",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(book)
    })
    alert('Book successfully edited!')
}
async function getData() {
    const response = await fetch('https://books-76270-default-rtdb.firebaseio.com/books/.json')
    const data = await response.json()
    return data
}
function findBook(old, data) {
    for (const key in data) {
        if (data[key].name == old) {
            return key
        }
    }
}
document.getElementById('edit').addEventListener('click',add)